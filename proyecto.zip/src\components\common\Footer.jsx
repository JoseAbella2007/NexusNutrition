import { Link } from "react-router-dom";
import Logo from "./Logo";
import { useAutenticacion } from "../../context/ContextoAutenticacion";
import { RUTAS } from "../../routes/rutas";
import "./Footer.css";

function irAlComienzo() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}

export default function Footer() {
  const { estaAutenticado, esAdministrador, usuario } = useAutenticacion();
  const destinoProductos = esAdministrador
    ? RUTAS.ADMIN
    : estaAutenticado
      ? RUTAS.PRODUCTOS
      : RUTAS.REGISTRO;

  return (
    <footer className="pie-pagina">
      <div className="contenedor pie-pagina__interior">
        <div className="pie-pagina__marca">
          <Link to={RUTAS.INICIO} onClick={irAlComienzo}>
            <Logo size="sm" />
          </Link>
          <p className="pie-pagina__lema">
            Nutrición premium diseñada para acompañar tu rendimiento, tu
            disciplina y tus objetivos.
          </p>
        </div>

        <div className="pie-pagina__columnas">
          <div className="pie-pagina__columna">
            <span className="pie-pagina__columna-titulo">Marca</span>
            <Link to={RUTAS.INICIO} onClick={irAlComienzo}>
              Inicio
            </Link>
            <Link to={destinoProductos}>Productos</Link>
          </div>

          {estaAutenticado && (
            <div className="pie-pagina__columna">
              <span className="pie-pagina__columna-titulo">Legal</span>
              <Link to={RUTAS.NO_ENCONTRADA}>Términos y condiciones</Link>
              <Link to={RUTAS.NO_ENCONTRADA}>Política de privacidad</Link>
            </div>
          )}

          <div className="pie-pagina__columna">
            <span className="pie-pagina__columna-titulo">Cuenta</span>
            {estaAutenticado ? (
              <div className="pie-pagina__sesion">
                <span className="pie-pagina__sesion-texto">
                  Sesión iniciada como {usuario.nombre.split(" ")[0]}
                </span>
                <span className="pie-pagina__sesion-icono" aria-hidden="true">
                  <svg viewBox="0 0 24 24" fill="none">
                    <path
                      d="M5 13l4 4L19 7"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
              </div>
            ) : (
              <>
                <Link to={RUTAS.INICIAR_SESION}>Iniciar sesión</Link>
                <Link to={RUTAS.REGISTRO}>Crear cuenta</Link>
              </>
            )}
          </div>

          {!estaAutenticado && (
            <div className="pie-pagina__columna">
              <span className="pie-pagina__columna-titulo">Legal</span>
              <Link to={RUTAS.NO_ENCONTRADA}>Términos y condiciones</Link>
              <Link to={RUTAS.NO_ENCONTRADA}>Política de privacidad</Link>
            </div>
          )}
        </div>
      </div>

      <div className="pie-pagina__inferior">
        <div className="contenedor pie-pagina__inferior-interior">
          <span>
            © {new Date().getFullYear()} Nexus Nutrition. Todos los derechos
            reservados.
          </span>
          <span className="pie-pagina__firma">
            Ciencia · Rendimiento · Evolución
          </span>
        </div>
      </div>
    </footer>
  );
}
